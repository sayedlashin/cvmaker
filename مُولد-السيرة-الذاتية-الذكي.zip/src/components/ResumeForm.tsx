import React, { useState } from 'react';
import { ResumeData, Experience, Education, Language } from '../types';
import { Plus, Trash2, Upload, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface Props {
  data: ResumeData;
  onChange: (data: ResumeData) => void;
  onUpload: (file: File) => Promise<void>;
  isUploading: boolean;
}

export const ResumeForm: React.FC<Props> = ({ data, onChange, onUpload, isUploading }) => {
  const [activeTab, setActiveTab] = useState<'personal' | 'summary' | 'experience' | 'education' | 'skills'>('personal');

  const updateContact = (field: keyof ResumeData['contact'], value: string) => {
    onChange({
      ...data,
      contact: { ...data.contact, [field]: value }
    });
  };

  const addExperience = () => {
    const newExp: Experience = { company: "", position: "", period: "", description: [""] };
    onChange({ ...data, experience: [...data.experience, newExp] });
  };

  const updateExperience = (index: number, field: keyof Experience, value: any) => {
    const newExperience = [...data.experience];
    newExperience[index] = { ...newExperience[index], [field]: value };
    onChange({ ...data, experience: newExperience });
  };

  const removeExperience = (index: number) => {
    onChange({ ...data, experience: data.experience.filter((_, i) => i !== index) });
  };

  const addEducation = () => {
    const newEdu: Education = { institution: "", degree: "", period: "", location: "" };
    onChange({ ...data, education: [...data.education, newEdu] });
  };

  const updateEducation = (index: number, field: keyof Education, value: string) => {
    const newEducation = [...data.education];
    newEducation[index] = { ...newEducation[index], [field]: value };
    onChange({ ...data, education: newEducation });
  };

  const removeEducation = (index: number) => {
    onChange({ ...data, education: data.education.filter((_, i) => i !== index) });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUpload(file);
    }
  };

  const tabs = [
    { id: 'personal', label: 'المعلومات الشخصية' },
    { id: 'summary', label: 'الملخص' },
    { id: 'experience', label: 'الخبرة' },
    { id: 'education', label: 'التعليم' },
    { id: 'skills', label: 'المهارات واللغات' },
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg border border-gray-100 overflow-hidden" dir="rtl">
      {/* Upload Section */}
      <div className="p-6 bg-gradient-to-r from-indigo-600 to-indigo-800 text-white">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold flex items-center gap-2">
              <Sparkles size={24} className="text-yellow-400" />
              استيراد بالذكاء الاصطناعي
            </h2>
            <p className="text-indigo-100 text-sm mt-1">ارفع سيرتك الذاتية القديمة لاستخراج البيانات تلقائياً</p>
          </div>
          <label className={`flex flex-col items-center justify-center bg-white/20 hover:bg-white/30 border-2 border-dashed border-white/50 rounded-lg px-6 py-3 cursor-pointer transition-all ${isUploading ? 'opacity-50 cursor-not-allowed' : ''}`}>
            <div className="flex items-center gap-2 font-medium">
              <Upload size={20} />
              <span>{isUploading ? 'جاري الاستخراج...' : 'رفع ملف'}</span>
            </div>
            <input type="file" className="hidden" onChange={handleFileUpload} accept=".pdf,.doc,.docx,.txt" disabled={isUploading} />
          </label>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200 bg-gray-50 overflow-x-auto invisible-scrollbar">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-6 py-4 text-sm font-medium whitespace-nowrap transition-colors relative ${
              activeTab === tab.id ? 'text-indigo-600' : 'text-gray-500 hover:text-indigo-400'
            }`}
          >
            {tab.label}
            {activeTab === tab.id && (
              <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-600" />
            )}
          </button>
        ))}
      </div>

      <div className="p-8 max-h-[700px] overflow-y-auto">
        <AnimatePresence mode="wait">
          {activeTab === 'personal' && (
            <motion.div
              key="personal"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-4"
            >
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700">الاسم الكامل</label>
                  <input
                    type="text"
                    value={data.name}
                    onChange={(e) => onChange({...data, name: e.target.value})}
                    placeholder="مثال: أحمد محمد"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700">المسمى الوظيفي</label>
                  <input
                    type="text"
                    value={data.title}
                    onChange={(e) => onChange({...data, title: e.target.value})}
                    placeholder="مثال: مطور برمجيات"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700">البريد الإلكتروني</label>
                  <input
                    type="email"
                    value={data.contact.email}
                    onChange={(e) => updateContact('email', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-semibold text-gray-700">رقم الهاتف</label>
                  <input
                    type="text"
                    value={data.contact.phone}
                    onChange={(e) => updateContact('phone', e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">الموقع</label>
                <input
                  type="text"
                  value={data.contact.location}
                  onChange={(e) => updateContact('location', e.target.value)}
                  placeholder="مثال: الرياض، السعودية"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
            </motion.div>
          )}

          {activeTab === 'summary' && (
            <motion.div
              key="summary"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-2"
            >
              <label className="text-sm font-semibold text-gray-700">الملخص المهني</label>
              <textarea
                value={data.summary}
                onChange={(e) => onChange({...data, summary: e.target.value})}
                rows={6}
                placeholder="اكتب نبذة مختصرة عن خبراتك وأهدافك المهنية..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
              />
            </motion.div>
          )}

          {activeTab === 'experience' && (
            <motion.div
              key="experience"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              {data.experience.map((exp, idx) => (
                <div key={idx} className="p-4 border border-gray-200 rounded-xl bg-gray-50 space-y-4">
                  <div className="flex justify-between items-center">
                    <h4 className="font-bold text-indigo-800">وظيفة #{idx + 1}</h4>
                    <button onClick={() => removeExperience(idx)} className="text-red-500 hover:text-red-700">
                      <Trash2 size={18} />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      placeholder="الشركة"
                      value={exp.company}
                      onChange={(e) => updateExperience(idx, 'company', e.target.value)}
                      className="px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                    <input
                      placeholder="المسمى الوظيفي"
                      value={exp.position}
                      onChange={(e) => updateExperience(idx, 'position', e.target.value)}
                      className="px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                  <input
                    placeholder="الفترة (مثال: 2020 - الحالي)"
                    value={exp.period}
                    onChange={(e) => updateExperience(idx, 'period', e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-500">الوصف (نقاط)</label>
                    <textarea
                      value={exp.description.join('\n')}
                      onChange={(e) => updateExperience(idx, 'description', e.target.value.split('\n'))}
                      rows={4}
                      placeholder="كل سطر يعتبر نقطة جديدة..."
                      className="w-full px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-indigo-500 text-sm"
                    />
                  </div>
                </div>
              ))}
              <button 
                onClick={addExperience}
                className="w-full py-4 border-2 border-dashed border-indigo-300 text-indigo-600 rounded-xl flex items-center justify-center gap-2 hover:bg-indigo-50 transition-colors"
              >
                <Plus size={20} />
                إضافة خبرة
              </button>
            </motion.div>
          )}

          {activeTab === 'education' && (
            <motion.div
              key="education"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              {data.education.map((edu, idx) => (
                <div key={idx} className="p-4 border border-gray-200 rounded-xl bg-gray-50 space-y-4">
                  <div className="flex justify-between items-center">
                    <h4 className="font-bold text-indigo-800">تعليم #{idx + 1}</h4>
                    <button onClick={() => removeEducation(idx)} className="text-red-500 hover:text-red-700">
                      <Trash2 size={18} />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      placeholder="المؤسسة / الجامعة"
                      value={edu.institution}
                      onChange={(e) => updateEducation(idx, 'institution', e.target.value)}
                      className="px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                    <input
                      placeholder="الدرجة العلمية"
                      value={edu.degree}
                      onChange={(e) => updateEducation(idx, 'degree', e.target.value)}
                      className="px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <input
                      placeholder="الفترة"
                      value={edu.period}
                      onChange={(e) => updateEducation(idx, 'period', e.target.value)}
                      className="px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                    <input
                      placeholder="الموقع"
                      value={edu.location}
                      onChange={(e) => updateEducation(idx, 'location', e.target.value)}
                      className="px-3 py-2 border rounded-lg outline-none focus:ring-1 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              ))}
              <button 
                onClick={addEducation}
                className="w-full py-4 border-2 border-dashed border-indigo-300 text-indigo-600 rounded-xl flex items-center justify-center gap-2 hover:bg-indigo-50 transition-colors"
              >
                <Plus size={20} />
                إضافة تعليم
              </button>
            </motion.div>
          )}

          {activeTab === 'skills' && (
            <motion.div
              key="skills"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="space-y-6"
            >
              <div className="space-y-2">
                <label className="text-sm font-semibold text-gray-700">المهارات (افصل بينها بفاصلة)</label>
                <textarea
                  value={data.skills.join(', ')}
                  onChange={(e) => onChange({...data, skills: e.target.value.split(',').map(s => s.trim()).filter(s => s)})}
                  rows={4}
                  placeholder="مثال: جافاسكريبت، حل المشكلات، العمل الجماعي..."
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
                />
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-semibold text-gray-700">اللغات</label>
                  <button 
                    onClick={() => onChange({...data, languages: [...data.languages, { language: "", level: "" }]})}
                    className="text-xs text-indigo-600 hover:underline flex items-center gap-1"
                  >
                    <Plus size={14} /> إضافة لغة
                  </button>
                </div>
                {data.languages.map((lang, idx) => (
                  <div key={idx} className="flex gap-2">
                    <input
                      placeholder="اللغة"
                      value={lang.language}
                      onChange={(e) => {
                        const newLangs = [...data.languages];
                        newLangs[idx].language = e.target.value;
                        onChange({...data, languages: newLangs});
                      }}
                      className="flex-1 px-3 py-2 border rounded-lg focus:ring-1 focus:ring-indigo-500 outline-none"
                    />
                    <select
                      value={lang.level}
                      onChange={(e) => {
                        const newLangs = [...data.languages];
                        newLangs[idx].level = e.target.value;
                        onChange({...data, languages: newLangs});
                      }}
                      className="px-3 py-2 border rounded-lg focus:ring-1 focus:ring-indigo-500 outline-none"
                    >
                      <option value="">اختر المستوى</option>
                      <option value="مبتدئ">مبتدئ</option>
                      <option value="متوسط">متوسط</option>
                      <option value="متقدم">متقدم</option>
                      <option value="اللغة الأم">اللغة الأم</option>
                    </select>
                    <button 
                      onClick={() => onChange({...data, languages: data.languages.filter((_, i) => i !== idx)})}
                      className="text-red-500"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
