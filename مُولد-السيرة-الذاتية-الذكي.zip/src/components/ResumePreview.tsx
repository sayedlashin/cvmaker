import React from 'react';
import { ResumeData } from '../types';
import { Mail, Phone, MapPin, Linkedin, Globe } from 'lucide-react';

interface Props {
  data: ResumeData;
}

export const ResumePreview: React.FC<Props> = ({ data }) => {
  return (
    <div className="bg-white p-8 shadow-2xl min-h-[1122px] w-full max-w-[800px] mx-auto text-right font-sans text-gray-800" dir="rtl" id="resume-preview">
      {/* Header */}
      <header className="border-b-2 border-gray-900 pb-6 mb-8 text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-2 uppercase tracking-tight">{data.name || "الاسم الكامل"}</h1>
        <p className="text-xl text-gray-600 mb-4">{data.title || "المسمى الوظيفي"}</p>
        
        <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-500">
          {data.contact.phone && (
            <span className="flex items-center gap-1">
              <Phone size={14} />
              {data.contact.phone}
            </span>
          )}
          {data.contact.email && (
            <span className="flex items-center gap-1">
              <Mail size={14} />
              {data.contact.email}
            </span>
          )}
          {data.contact.location && (
            <span className="flex items-center gap-1">
              <MapPin size={14} />
              {data.contact.location}
            </span>
          )}
          {data.contact.linkedin && (
            <span className="flex items-center gap-1">
              <Linkedin size={14} />
              {data.contact.linkedin}
            </span>
          )}
          {data.contact.website && (
            <span className="flex items-center gap-1">
              <Globe size={14} />
              {data.contact.website}
            </span>
          )}
        </div>
      </header>

      <div className="space-y-8">
        {/* Summary */}
        {data.summary && (
          <section>
            <h2 className="text-lg font-bold border-b border-gray-300 mb-3 pb-1 uppercase tracking-wider text-gray-900">الملخص المهني</h2>
            <p className="text-gray-700 leading-relaxed text-justify">{data.summary}</p>
          </section>
        )}

        {/* Experience */}
        {data.experience.length > 0 && (
          <section>
            <h2 className="text-lg font-bold border-b border-gray-300 mb-4 pb-1 uppercase tracking-wider text-gray-900">الخبرة العملية</h2>
            <div className="space-y-6">
              {data.experience.map((exp, index) => (
                <div key={index} className="relative">
                  <div className="flex justify-between items-baseline mb-1">
                    <h3 className="font-bold text-gray-900">{exp.company}</h3>
                    <span className="text-xs font-mono text-gray-500">{exp.period}</span>
                  </div>
                  <p className="text-gray-700 font-medium text-sm mb-2 italic">{exp.position}</p>
                  <ul className="list-disc list-inside space-y-1 mr-2">
                    {exp.description.map((desc, i) => (
                      <li key={i} className="text-sm text-gray-600 leading-snug">{desc}</li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Education */}
        {data.education.length > 0 && (
          <section>
            <h2 className="text-lg font-bold border-b border-gray-300 mb-4 pb-1 uppercase tracking-wider text-gray-900">التعليم</h2>
            <div className="space-y-4">
              {data.education.map((edu, index) => (
                <div key={index}>
                  <div className="flex justify-between items-baseline">
                    <h3 className="font-bold text-gray-900">{edu.institution}</h3>
                    <span className="text-xs font-mono text-gray-500">{edu.period}</span>
                  </div>
                  <p className="text-sm text-gray-700">{edu.degree}</p>
                  <p className="text-xs text-gray-500">{edu.location}</p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Skills & Languages */}
        <div className="grid grid-cols-2 gap-8">
          {data.skills.length > 0 && (
            <section>
              <h2 className="text-lg font-bold border-b border-gray-300 mb-3 pb-1 uppercase tracking-wider text-gray-900">المهارات</h2>
              <div className="flex flex-wrap gap-2 text-sm text-gray-700">
                {data.skills.join(" • ")}
              </div>
            </section>
          )}

          {data.languages.length > 0 && (
            <section>
              <h2 className="text-lg font-bold border-b border-gray-300 mb-3 pb-1 uppercase tracking-wider text-gray-900">اللغات</h2>
              <div className="space-y-1">
                {data.languages.map((lang, index) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span className="font-bold text-gray-900">{lang.language}</span>
                    <span className="text-gray-600">{lang.level}</span>
                  </div>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
    </div>
  );
};
