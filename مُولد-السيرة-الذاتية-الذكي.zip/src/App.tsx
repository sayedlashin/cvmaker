import React, { useState, useEffect } from 'react';
import { ResumeForm } from './components/ResumeForm';
import { ResumePreview } from './components/ResumePreview';
import { ResumeData, initialData } from './types';
import { generateDocx } from './lib/exportDocx';
import { FileDown, FileText, CheckCircle, Info } from 'lucide-react';
import { motion } from 'motion/react';

export default function App() {
  const [data, setData] = useState<ResumeData>(initialData);
  const [isUploading, setIsUploading] = useState(false);
  const [showToast, setShowToast] = useState<string | null>(null);

  // Auto-save to local storage
  useEffect(() => {
    const saved = localStorage.getItem('resume-data');
    if (saved) {
      try {
        setData(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load saved data");
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('resume-data', JSON.stringify(data));
  }, [data]);

  const handleUpload = async (file: File) => {
    setIsUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('/api/extract-cv', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error('Extraction failed');

      const extracted = await response.json();
      setData(extracted);
      setShowToast("تم استخراج البيانات بنجاح!");
      setTimeout(() => setShowToast(null), 3000);
    } catch (error) {
      console.error(error);
      alert("فشل استخراج البيانات. الرجاء المحاولة مرة أخرى.");
    } finally {
      setIsUploading(false);
    }
  };

  const handleExport = async () => {
    try {
      await generateDocx(data);
    } catch (error) {
      console.error(error);
      alert("فشل تصدير الملف.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans selection:bg-indigo-100" dir="rtl">
      {/* Navigation */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex items-center gap-2">
              <div className="bg-indigo-600 p-2 rounded-lg">
                <FileText className="text-white" size={24} />
              </div>
              <span className="font-bold text-xl tracking-tight text-indigo-900">مُولد السيرة الذاتية الذكي</span>
            </div>
            <div className="flex items-center gap-4">
              <button 
                onClick={handleExport}
                className="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-full font-medium transition-all flex items-center gap-2 shadow-lg hover:shadow-indigo-200 transform hover:-translate-y-0.5 active:scale-95"
              >
                <FileDown size={20} />
                تحميل الملف (Word)
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid lg:grid-cols-2 gap-10 items-start">
          
          {/* Left Column: Form */}
          <div className="space-y-8 lg:sticky lg:top-24">
            <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl flex gap-3 text-blue-800">
              <Info className="shrink-0 mt-1" size={20} />
              <div>
                <p className="text-sm font-medium">سيرتك الذاتية متوافقة تلقائياً مع أنظمة ATS</p>
                <p className="text-xs mt-1 opacity-80">التنسيق البسيط والنظيف هو الأفضل لخوارزميات التوظيف الحديثة.</p>
              </div>
            </div>
            
            <ResumeForm 
              data={data} 
              onChange={setData} 
              onUpload={handleUpload}
              isUploading={isUploading}
            />
          </div>

          {/* Right Column: Preview */}
          <div className="hidden lg:block">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-gray-600 flex items-center gap-2">
                <CheckCircle size={18} className="text-green-500" />
                معاينة حية (A4)
              </h3>
            </div>
            <div className="transform scale-[0.85] origin-top border border-gray-200 shadow-2xl rounded-sm">
              <ResumePreview data={data} />
            </div>
          </div>

          {/* Mobile Preview Trigger (Visible only on mobile) */}
          <div className="lg:hidden">
             <h3 className="font-bold text-gray-600 mb-4 px-2">معاينة السيرة الذاتية</h3>
             <ResumePreview data={data} />
          </div>

        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-10 mt-20">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-gray-500 text-sm">تم التطوير لدعم الباحثين عن عمل بأفضل التقنيات.</p>
        </div>
      </footer>

      {/* Toast Notification */}
      {showToast && (
        <div className="fixed bottom-10 right-10 bg-indigo-900 text-white px-8 py-4 rounded-xl shadow-2xl z-[100] animate-bounce rtl">
          {showToast}
        </div>
      )}
    </div>
  );
}
