import { 
  Document, 
  Packer, 
  Paragraph, 
  TextRun, 
  HeadingLevel, 
  AlignmentType,
  BorderStyle,
  Table,
  TableRow,
  TableCell,
  WidthType
} from "docx";
import { saveAs } from "file-saver";
import { ResumeData } from "../types";

export const generateDocx = async (data: ResumeData) => {
  const doc = new Document({
    sections: [
      {
        properties: {},
        children: [
          // Name and Title
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: data.name || "الاسم الكامل",
                bold: true,
                size: 32,
              }),
            ],
            bidirectional: true,
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: data.title || "المسمى الوظيفي",
                size: 24,
                color: "666666",
              }),
            ],
            bidirectional: true,
          }),

          // Contact info
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 200, after: 400 },
            children: [
              new TextRun({
                text: `${data.contact.phone} | ${data.contact.email} | ${data.contact.location}`,
                size: 20,
              }),
            ],
            bidirectional: true,
          }),

          // Summary
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            children: [new TextRun({ text: "الملخص المهني", bold: true })],
            bidirectional: true,
            border: { bottom: { color: "000000", space: 1, style: BorderStyle.SINGLE, size: 6 } },
          }),
          new Paragraph({
            spacing: { before: 200, after: 400 },
            children: [new TextRun({ text: data.summary })],
            bidirectional: true,
          }),

          // Experience
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            children: [new TextRun({ text: "الخبرة العملية", bold: true })],
            bidirectional: true,
            border: { bottom: { color: "000000", space: 1, style: BorderStyle.SINGLE, size: 6 } },
          }),
          ...data.experience.flatMap((exp) => [
            new Paragraph({
              spacing: { before: 200 },
              children: [
                new TextRun({ text: exp.company, bold: true }),
                new TextRun({ text: ` | ${exp.position}`, italics: true }),
              ],
              bidirectional: true,
            }),
            new Paragraph({
              children: [new TextRun({ text: exp.period, size: 18, color: "888888" })],
              bidirectional: true,
            }),
            ...exp.description.map(
              (desc) =>
                new Paragraph({
                  bullet: { level: 0 },
                  children: [new TextRun({ text: desc })],
                  bidirectional: true,
                })
            ),
          ]),

          // Education
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 400 },
            children: [new TextRun({ text: "التعليم", bold: true })],
            bidirectional: true,
            border: { bottom: { color: "000000", space: 1, style: BorderStyle.SINGLE, size: 6 } },
          }),
          ...data.education.flatMap((edu) => [
            new Paragraph({
              spacing: { before: 200 },
              children: [
                new TextRun({ text: edu.institution, bold: true }),
                new TextRun({ text: ` | ${edu.degree}`, italics: true }),
              ],
              bidirectional: true,
            }),
            new Paragraph({
              children: [
                new TextRun({ text: `${edu.period} | ${edu.location}`, size: 18, color: "888888" }),
              ],
              bidirectional: true,
            }),
          ]),

          // Skills
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 400 },
            children: [new TextRun({ text: "المهارات", bold: true })],
            bidirectional: true,
            border: { bottom: { color: "000000", space: 1, style: BorderStyle.SINGLE, size: 6 } },
          }),
          new Paragraph({
            spacing: { before: 200 },
            children: [new TextRun({ text: data.skills.join(" ، ") })],
            bidirectional: true,
          }),

          // Languages
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            spacing: { before: 400 },
            children: [new TextRun({ text: "اللغات", bold: true })],
            bidirectional: true,
            border: { bottom: { color: "000000", space: 1, style: BorderStyle.SINGLE, size: 6 } },
          }),
          ...data.languages.map(
            (lang) =>
              new Paragraph({
                spacing: { before: 100 },
                children: [
                  new TextRun({ text: lang.language, bold: true }),
                  new TextRun({ text: ` (${lang.level})` }),
                ],
                bidirectional: true,
              })
          ),
        ],
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  saveAs(blob, `CV_${data.name.replace(/\s+/g, "_")}.docx`);
};
